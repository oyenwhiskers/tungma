<?php $__env->startSection('content'); ?>
    <div class="tm-header">
        <div>
            <h2>Activity Logs</h2>
            <div class="text-muted">Track all system activities and changes.</div>
        </div>
        <div class="d-flex align-items-center gap-2">
            <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left"></i> Back to dashboard
            </a>
        </div>
    </div>

    <div class="tm-card mb-4">
        <div class="tm-card-body py-3">
            <form action="<?php echo e(route('activity-logs.index')); ?>" method="GET"
                class="d-flex flex-wrap align-items-center gap-3">
                <div class="d-flex align-items-center gap-2">
                    <label class="text-muted small fw-medium text-uppercase">Filter by:</label>
                    <select name="action" class="form-select form-select-sm" style="width: 150px;"
                        onchange="this.form.submit()">
                        <option value="">All Actions</option>
                        <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($action); ?>" <?php echo e(request('action') == $action ? 'selected' : ''); ?>>
                                <?php echo e(ucfirst($action)); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <select name="module" class="form-select form-select-sm" style="width: 150px;"
                        onchange="this.form.submit()">
                        <option value="">All Modules</option>
                        <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($module); ?>" <?php echo e(request('module') == $module ? 'selected' : ''); ?>>
                                <?php echo e($module); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <input type="date" name="date" class="form-control form-control-sm" style="width: 150px;"
                           value="<?php echo e(request('date')); ?>" onchange="this.form.submit()">
                </div>

                <?php if(request('action') || request('module') || request('date')): ?>
                    <a href="<?php echo e(route('activity-logs.index')); ?>"
                        class="btn btn-link btn-sm text-danger text-decoration-none px-0">
                        <i class="bi bi-x-circle"></i> Clear filters
                    </a>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <div class="tm-card border-0 shadow-sm">
        <div class="tm-card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-top mb-0" style="table-layout: fixed;">
                    <thead class="bg-light border-bottom">
                        <tr>
                            <th class="ps-4 py-3 text-muted fw-bold text-uppercase" style="width: 220px; font-size: 11px; letter-spacing: 0.5px;">User</th>
                            <th class="py-3 text-muted fw-bold text-uppercase" style="width: 120px; font-size: 11px; letter-spacing: 0.5px;">Context</th>
                            <th class="py-3 text-muted fw-bold text-uppercase" style="font-size: 11px; letter-spacing: 0.5px;">Changes</th>
                            <th class="pe-4 py-3 text-end text-muted fw-bold text-uppercase" style="width: 150px; font-size: 11px; letter-spacing: 0.5px;">
                                <a href="<?php echo e(route('activity-logs.index', array_merge(request()->query(), ['sort' => request('sort') === 'asc' ? 'desc' : 'asc']))); ?>" 
                                   class="text-decoration-none text-muted d-flex align-items-center justify-content-end gap-1">
                                    Date
                                    <?php if(request('sort') === 'asc'): ?>
                                        <i class="bi bi-arrow-up"></i>
                                    <?php else: ?>
                                        <i class="bi bi-arrow-down"></i>
                                    <?php endif; ?>
                                </a>
                            </th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="ps-4 py-3">
                                    <div class="d-flex align-items-center gap-3">
                                        <div class="avatar-circle shadow-sm"
                                            style="width: 36px; height: 36px; background: linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #4b5563; border: 2px solid white;">
                                            <span style="font-size: 13px; font-weight: 700;"><?php echo e(substr($log->user->name ?? 'S', 0, 1)); ?></span>
                                        </div>
                                        <div class="d-flex flex-column" style="line-height: 1.3;">
                                            <span class="fw-semibold text-dark" style="font-size: 14px;"><?php echo e($log->user->name ?? 'System'); ?></span>
                                            <span class="text-muted" style="font-size: 11px;"><?php echo e($log->ip_address); ?></span>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-3">
                                    <div class="d-flex flex-column gap-1">
                                        <?php
                                            $actionColor = match ($log->action) {
                                                'created' => 'success',
                                                'updated' => 'primary',
                                                'deleted' => 'danger',
                                                default => 'secondary',
                                            };
                                            $actionIcon = match ($log->action) {
                                                'created' => 'bi-plus-lg',
                                                'updated' => 'bi-pencil',
                                                'deleted' => 'bi-trash',
                                                default => 'bi-circle',
                                            };
                                            $moduleIcon = match ($log->model) {
                                                'User' => 'bi-person',
                                                'Bill' => 'bi-receipt',
                                                'Company' => 'bi-building',
                                                'BusDepartures' => 'bi-bus-front',
                                                'CourierPolicy' => 'bi-file-text',
                                                default => 'bi-box',
                                            };
                                        ?>
                                        <div class="d-flex align-items-center gap-2 mb-1">
                                            <span class="badge bg-<?php echo e($actionColor); ?>-subtle text-<?php echo e($actionColor); ?> border border-<?php echo e($actionColor); ?>-subtle rounded-pill d-inline-flex align-items-center gap-1 px-2 py-1" style="font-weight: 600; font-size: 10px;">
                                                <i class="<?php echo e($actionIcon); ?>"></i> <?php echo e(ucfirst($log->action)); ?>

                                            </span>
                                        </div>
                                        <div class="d-flex align-items-center text-muted small" style="font-size: 12px;">
                                            <i class="<?php echo e($moduleIcon); ?> me-1 opacity-75"></i>
                                            <span class="fw-medium"><?php echo e($log->model); ?></span>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-3">
                                    <div class="bg-light rounded-3 p-3 border border-light-subtle">
                                        <?php if($log->action === 'updated'): ?>
                                            <div class="d-flex flex-column gap-2">
                                                <?php $__currentLoopData = ($log->new_values ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $newValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $oldValue = $log->old_values[$key] ?? null;
                                                        if (in_array($key, ['updated_at', 'created_at'])) continue;
                                                        if ($oldValue == $newValue) continue; 
                                                    ?>
                                                    <div class="d-flex flex-column flex-sm-row gap-1 gap-sm-2 text-break" style="font-size: 13px;">
                                                        <span class="fw-semibold text-secondary min-w-100" style="min-width: 120px;">
                                                            <?php echo e(ucwords(str_replace('_', ' ', $key))); ?>

                                                        </span>
                                                        <div class="d-flex align-items-center gap-2 flex-wrap">
                                                            <span class="text-danger bg-danger-subtle px-1 rounded text-decoration-line-through opacity-75 small">
                                                                <?php echo e(is_array($oldValue) ? 'Array' : Str::limit($oldValue, 40)); ?>

                                                            </span>
                                                            <i class="bi bi-arrow-right-short text-muted"></i>
                                                            <span class="text-success fw-medium">
                                                                <?php echo e(is_array($newValue) ? 'Array' : Str::limit($newValue, 40)); ?>

                                                            </span>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        <?php elseif($log->action === 'created'): ?>
                                            <div class="row g-2">
                                                <?php $__currentLoopData = ($log->new_values ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(in_array($key, ['created_at', 'updated_at', 'deleted_at', 'id'])): ?> <?php continue; ?> <?php endif; ?>
                                                    <?php if(empty($value)): ?> <?php continue; ?> <?php endif; ?>
                                                    <div class="col-6 col-md-4" style="font-size: 12px;">
                                                        <span class="text-muted d-block small"><?php echo e(ucwords(str_replace('_', ' ', $key))); ?></span>
                                                        <span class="text-dark fw-medium text-break"><?php echo e(is_array($value) ? 'Array' : Str::limit((string)$value, 50)); ?></span>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        <?php elseif($log->action === 'deleted'): ?>
                                            <div class="row g-2">
                                                <div class="col-12 mb-1">
                                                    <span class="badge bg-danger-subtle text-danger border border-danger-subtle" style="font-size: 10px;">Deleted Data Snapshot</span>
                                                </div>
                                                <?php $__currentLoopData = ($log->old_values ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(in_array($key, ['created_at', 'updated_at', 'deleted_at', 'id'])): ?> <?php continue; ?> <?php endif; ?>
                                                    <?php if(empty($value)): ?> <?php continue; ?> <?php endif; ?>
                                                    <div class="col-6 col-md-4" style="font-size: 12px;">
                                                        <span class="text-muted d-block small"><?php echo e(ucwords(str_replace('_', ' ', $key))); ?></span>
                                                        <span class="text-secondary text-decoration-line-through text-break"><?php echo e(is_array($value) ? 'Array' : Str::limit((string)$value, 50)); ?></span>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-muted small fst-italic">No detailed changes recorded.</span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td class="pe-4 py-3 text-end">
                                    <div class="d-flex flex-column">
                                        <span class="fw-semibold text-dark" style="font-size: 13px;"><?php echo e($log->created_at->format('M d, Y')); ?></span>
                                        <span class="text-muted" style="font-size: 11px;"><?php echo e($log->created_at->format('h:i A')); ?></span>
                                        <span class="text-muted small mt-1" style="font-size: 10px;"><?php echo e($log->created_at->diffForHumans()); ?></span>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center py-5">
                                    <div class="d-flex flex-column align-items-center justify-content-center">
                                        <div class="bg-light rounded-circle p-4 mb-3">
                                            <i class="bi bi-clipboard-data text-muted opacity-50 display-6"></i>
                                        </div>
                                        <h5 class="text-muted fw-medium fs-6">No activities found</h5>
                                        <p class="text-muted small mb-0">Try adjusting your filters or come back later.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php if($logs->hasPages()): ?>
                <div class="px-4 py-3 border-top">
                    <?php echo e($logs->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\tungma\resources\views/activity_logs/index.blade.php ENDPATH**/ ?>
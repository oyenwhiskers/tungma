<?php $__env->startSection('content'); ?>
<div class="tm-header">
  <div>
    <h2 class="mb-1">Dashboard</h2>
    <div class="text-muted">
      <?php if(auth()->user()->role === 'super_admin'): ?>
        Overview of all logistics operations
      <?php else: ?>
        Overview of <?php echo e(auth()->user()->company->name ?? 'your company'); ?> operations
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="row g-3 mb-4">
  <?php if(auth()->user()->role === 'super_admin'): ?>
  <div class="col-md-3">
    <div class="tm-card">
      <div class="tm-card-body tm-kpi">
        <div class="d-flex justify-content-between align-items-start">
          <div>
            <div class="label">Companies</div>
            <div class="value"><?php echo e($companies_count); ?></div>
          </div>
          <i class="bi bi-building text-muted" style="font-size:32px; opacity:0.15;"></i>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="tm-card">
      <div class="tm-card-body tm-kpi">
        <div class="d-flex justify-content-between align-items-start">
          <div>
            <div class="label">Admins</div>
            <div class="value"><?php echo e($admins_count); ?></div>
          </div>
          <i class="bi bi-person-badge text-muted" style="font-size:32px; opacity:0.15;"></i>
        </div>
      </div>
    </div>
  </div>
  <?php else: ?>
  <div class="col-md-3">
    <div class="tm-card">
      <div class="tm-card-body tm-kpi">
        <div class="d-flex justify-content-between align-items-start">
          <div>
            <div class="label">My Company</div>
            <div class="value" style="font-size:18px;"><?php echo e(auth()->user()->company->name ?? 'N/A'); ?></div>
          </div>
          <i class="bi bi-building text-muted" style="font-size:32px; opacity:0.15;"></i>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>
  <div class="col-md-3">
    <div class="tm-card">
      <div class="tm-card-body tm-kpi">
        <div class="d-flex justify-content-between align-items-start">
          <div>
            <div class="label">Staff</div>
            <div class="value"><?php echo e($staff_count); ?></div>
          </div>
          <i class="bi bi-people text-muted" style="font-size:32px; opacity:0.15;"></i>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="tm-card">
      <div class="tm-card-body tm-kpi">
        <div class="d-flex justify-content-between align-items-start">
          <div>
            <div class="label">Total Bills</div>
            <div class="value"><?php echo e($bills_count); ?></div>
          </div>
          <i class="bi bi-receipt text-muted" style="font-size:32px; opacity:0.15;"></i>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="tm-card">
      <div class="tm-card-body tm-kpi">
        <div class="d-flex justify-content-between align-items-start">
          <div>
            <div class="label">Total Revenue</div>
            <div class="value" style="font-size:24px;">RM <?php echo e(number_format($total_revenue, 2)); ?></div>
          </div>
          <i class="bi bi-cash-stack text-muted" style="font-size:32px; opacity:0.15;"></i>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="row g-3">
  <div class="col-md-8">
    <div class="tm-card">
      <div class="tm-card-header">
        <i class="bi bi-lightning-charge-fill me-2" style="color:var(--tm-accent);"></i>
        Quick Actions
      </div>
      <div class="tm-card-body">
        <div class="row g-2">
          <?php if(auth()->user()->role === 'super_admin'): ?>
          <div class="col-md-4">
            <a class="btn btn-outline-secondary w-100 text-start" href="<?php echo e(route('companies.create')); ?>">
              <i class="bi bi-building"></i> New Company
            </a>
          </div>
          <div class="col-md-4">
            <a class="btn btn-outline-secondary w-100 text-start" href="<?php echo e(route('admins.create')); ?>">
              <i class="bi bi-person-badge"></i> New Admin
            </a>
          </div>
          <?php endif; ?>
          <div class="col-md-4">
            <a class="btn btn-outline-secondary w-100 text-start" href="<?php echo e(route('staff.create')); ?>">
              <i class="bi bi-people"></i> New Staff
            </a>
          </div>
          <div class="col-md-4">
            <a class="btn btn-outline-secondary w-100 text-start" href="<?php echo e(route('policies.create')); ?>">
              <i class="bi bi-file-earmark-text"></i> New Policy
            </a>
          </div>
          <div class="col-md-4">
            <a class="btn btn-outline-secondary w-100 text-start" href="<?php echo e(route('bills.create')); ?>">
              <i class="bi bi-receipt"></i> New Bill
            </a>
          </div>
          <div class="col-md-4">
            <a class="btn btn-outline-secondary w-100 text-start" href="<?php echo e(route('analytics.index')); ?>">
              <i class="bi bi-graph-up"></i> View Analytics
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <div class="col-md-4">
    <div class="tm-card">
      <div class="tm-card-header">
        <i class="bi bi-info-circle me-2" style="color:var(--tm-primary);"></i>
        System Info
      </div>
      <div class="tm-card-body">
        <dl class="mb-0" style="font-size:13px;">
          <dt class="text-muted mb-1">
            <?php if(auth()->user()->role === 'super_admin'): ?>
              Total Bills
            <?php else: ?>
              My Bills
            <?php endif; ?>
          </dt>
          <dd class="mb-2"><?php echo e($bills_count); ?> bills</dd>
          <dt class="text-muted mb-1">
            <?php if(auth()->user()->role === 'super_admin'): ?>
              Total Users
            <?php else: ?>
              Company Users
            <?php endif; ?>
          </dt>
          <dd class="mb-2"><?php echo e($active_users); ?> active users</dd>
          <dt class="text-muted mb-1">System Status</dt>
          <dd class="mb-0"><span class="badge bg-success">Operational</span></dd>
        </dl>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\tungma\resources\views/dashboard.blade.php ENDPATH**/ ?>
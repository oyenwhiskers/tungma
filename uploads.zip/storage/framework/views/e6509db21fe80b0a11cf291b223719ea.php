

<?php $__env->startSection('content'); ?>
    <div class="tm-header">
        <div>
            <h2>Edit Departure</h2>
            <div class="text-muted">Update bus departure schedule.</div>
        </div>
        <div>
            <a href="<?php echo e(route('bus-departures.index')); ?>" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left"></i> Back
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="tm-card">
                <div class="tm-card-body">
                    <form action="<?php echo e(route('bus-departures.update', $busDeparture->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-3">
                            <label for="departure_time" class="form-label">Departure Time</label>
                            <input type="time" class="form-control" id="departure_time" name="departure_time"
                                value="<?php echo e($busDeparture->departure_time); ?>" required>
                        </div>
                        <div class="text-end">
                            <button type="submit" class="btn btn-primary">Update Departure</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\tungma\resources\views/bus_departures/edit.blade.php ENDPATH**/ ?>
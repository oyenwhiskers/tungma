<?php $__env->startSection('content'); ?>
<div class="tm-breadcrumb">
    <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
    <i class="bi bi-chevron-right"></i>
    <span>Admins</span>
</div>

<div class="tm-header">
  <div>
    <h2 class="mb-1">Admins</h2>
    <div class="text-muted">Manage administrator accounts and permissions</div>
  </div>
  <div>
    <a href="<?php echo e(route('admins.deleted')); ?>" class="btn btn-outline-secondary me-2">
        <i class="bi bi-trash"></i> Deleted Admins
    </a>
    <a href="<?php echo e(route('admins.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-circle"></i> New Admin
    </a>
  </div>
</div>

<div class="tm-card tm-table">
  <div class="tm-card-body">
    <?php if($admins->count() > 0): ?>
    <table class="table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Username</th>
          <th>Email</th>
          <th>Position</th>
          <th>Company</th>
          <th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td>
            <a href="<?php echo e(route('admins.show', $admin)); ?>" class="d-flex align-items-center gap-2">
              <i class="bi bi-person-badge"></i>
              <strong><?php echo e($admin->name); ?></strong>
            </a>
          </td>
          <td><?php echo e($admin->username ?? '—'); ?></td>
          <td><?php echo e($admin->email); ?></td>
          <td><?php echo e($admin->position ?? '—'); ?></td>
          <td><?php echo e($admin->company?->name ?? '—'); ?></td>
          <td class="text-end">
            <div class="btn-group btn-group-sm">
              <a href="<?php echo e(route('admins.show', $admin)); ?>" class="btn btn-outline-secondary">
                <i class="bi bi-eye"></i>
              </a>
              <a href="<?php echo e(route('admins.edit', $admin)); ?>" class="btn btn-outline-secondary">
                <i class="bi bi-pencil"></i>
              </a>
            </div>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <div class="d-flex justify-content-between align-items-center mt-3">
        <div class="text-muted" style="font-size:13px;">
            Showing <?php echo e($admins->firstItem() ?? 0); ?> to <?php echo e($admins->lastItem() ?? 0); ?> of <?php echo e($admins->total()); ?> admins
        </div>
        <div><?php echo e($admins->links()); ?></div>
    </div>
    <?php else: ?>
    <div class="tm-empty-state">
        <i class="bi bi-person-badge"></i>
        <div class="title">No admins found</div>
        <p>Create your first administrator account</p>
        <a href="<?php echo e(route('admins.create')); ?>" class="btn btn-primary mt-2">
            <i class="bi bi-plus-circle"></i> Create Admin
        </a>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\tungma\resources\views/admins/index.blade.php ENDPATH**/ ?>
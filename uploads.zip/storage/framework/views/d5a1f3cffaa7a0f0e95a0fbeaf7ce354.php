<?php $__env->startSection('content'); ?>
<div class="tm-breadcrumb">
    <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
    <i class="bi bi-chevron-right"></i>
    <a href="<?php echo e(route('staff.index')); ?>">Staff</a>
    <i class="bi bi-chevron-right"></i>
    <span>Deleted</span>
</div>

<div class="tm-header">
  <div>
    <h2 class="mb-1">Deleted Staff</h2>
    <div class="text-muted">Restore previously removed staff members to active status</div>
  </div>
  <a href="<?php echo e(route('staff.index')); ?>" class="btn btn-outline-secondary">
    <i class="bi bi-arrow-left"></i> Back to Staff
  </a>
</div>

<div class="tm-card tm-table">
  <div class="tm-card-body">
    <?php if($staff->count() > 0): ?>
    <table class="table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Username</th>
          <th>Email</th>
          <th>Company</th>
          <th>Deleted At</th>
          <th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td>
            <div class="d-flex align-items-center gap-2">
              <i class="bi bi-person text-muted"></i>
              <strong><?php echo e($user->name); ?></strong>
            </div>
          </td>
          <td><?php echo e($user->username ?? '—'); ?></td>
          <td><?php echo e($user->email); ?></td>
          <td><?php echo e($user->company?->name ?? '—'); ?></td>
          <td>
            <span class="text-muted small">
              <i class="bi bi-clock"></i> <?php echo e($user->deleted_at->format('M d, Y h:i A')); ?>

            </span>
          </td>
          <td class="text-end">
            <form method="post" action="<?php echo e(route('staff.restore', $user->id)); ?>" class="d-inline" onsubmit="return confirm('Are you sure you want to restore this staff member?');">
              <?php echo csrf_field(); ?>
              <button type="submit" class="btn btn-sm btn-success">
                <i class="bi bi-arrow-counterclockwise"></i> Restore
              </button>
            </form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <div class="d-flex justify-content-between align-items-center mt-3">
        <div class="text-muted" style="font-size:13px;">
            Showing <?php echo e($staff->firstItem() ?? 0); ?> to <?php echo e($staff->lastItem() ?? 0); ?> of <?php echo e($staff->total()); ?> deleted staff members
        </div>
        <div><?php echo e($staff->links()); ?></div>
    </div>
    <?php else: ?>
    <div class="tm-empty-state">
        <i class="bi bi-trash"></i>
        <div class="title">No deleted staff members</div>
        <p>All staff members are currently active</p>
        <a href="<?php echo e(route('staff.index')); ?>" class="btn btn-outline-secondary mt-2">
            <i class="bi bi-arrow-left"></i> Back to Staff
        </a>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\tungma\resources\views/staff/deleted.blade.php ENDPATH**/ ?>
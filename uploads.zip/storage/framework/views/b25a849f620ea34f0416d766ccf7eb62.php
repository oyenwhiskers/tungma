<?php $__env->startSection('content'); ?>
<div class="tm-breadcrumb">
    <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
    <i class="bi bi-chevron-right"></i>
    <span>Bills</span>
</div>

<div class="tm-header">
    <div>
        <h2 class="mb-1">Bills</h2>
        <div class="text-muted">Track and manage billing and invoices</div>
    </div>
    <div>
        <a href="<?php echo e(route('bills.deleted')); ?>" class="btn btn-outline-secondary me-2">
            <i class="bi bi-trash"></i> Deleted Bills
        </a>
        <a href="<?php echo e(route('bills.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-circle"></i> New Bill
        </a>
    </div>
</div>

<div class="tm-card">
    <div class="tm-card-header">
        <i class="bi bi-funnel me-2"></i> Filters
    </div>
    <div class="tm-card-body">
        <form method="GET" action="<?php echo e(route('bills.index')); ?>" class="row g-3">
            <div class="col-md-3">
                <label class="form-label small text-muted">Search</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                    <input type="text" name="search" class="form-control"
                           value="<?php echo e(request('search')); ?>"
                           placeholder="Bill code, description, customer...">
                </div>
            </div>

            <div class="col-md-2">
                <label class="form-label small text-muted">Payment Status</label>
                <select name="payment_status" class="form-select">
                    <option value="">All</option>
                    <option value="paid" <?php echo e(request('payment_status') == 'paid' ? 'selected' : ''); ?>>Paid</option>
                    <option value="unpaid" <?php echo e(request('payment_status') == 'unpaid' ? 'selected' : ''); ?>>Unpaid</option>
                </select>
            </div>

            <?php if(auth()->user()->role !== 'admin'): ?>
            <div class="col-md-2">
                <label class="form-label small text-muted">Company</label>
                <select name="company_id" class="form-select">
                    <option value="">All Companies</option>
                    <?php $__currentLoopData = $companies ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($company->id); ?>" <?php echo e(request('company_id') == $company->id ? 'selected' : ''); ?>>
                            <?php echo e($company->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <?php endif; ?>

            <div class="col-md-2">
                <label class="form-label small text-muted">Payment Method</label>
                <select name="payment_method" class="form-select">
                    <option value="">All Methods</option>
                    <option value="cash" <?php echo e(request('payment_method') == 'cash' ? 'selected' : ''); ?>>Cash</option>
                    <option value="bank_transfer" <?php echo e(request('payment_method') == 'bank_transfer' ? 'selected' : ''); ?>>Bank Transfer</option>
                    <option value="e_wallet_qr" <?php echo e(request('payment_method') == 'e_wallet_qr' ? 'selected' : ''); ?>>E-wallet/QR</option>
                    <option value="cod" <?php echo e(request('payment_method') == 'cod' ? 'selected' : ''); ?>>COD</option>
                </select>
            </div>

            <div class="col-md-2">
                <label class="form-label small text-muted">Date </label>
                <input type="date" name="date" class="form-control" value="<?php echo e(request('date')); ?>">
            </div>

            <div class="col-md-12">
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-funnel"></i> Apply Filters
                    </button>
                    <a href="<?php echo e(route('bills.index')); ?>" class="btn btn-outline-secondary">
                        <i class="bi bi-x-circle"></i> Clear
                    </a>
                    <?php if(request()->hasAny(['search', 'payment_status', 'company_id', 'payment_method', 'date'])): ?>
                        <span class="align-self-center text-muted small ms-2">
                            <i class="bi bi-info-circle"></i> <?php echo e($bills->total()); ?> result(s) found
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="tm-card tm-table mt-3">
    <div class="tm-card-body">
        <?php if($bills->count() > 0): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Bill Code</th>
                    <th>Date</th>
                    <th>Customer Received</th>
                    <th>Bus Departure</th>
                    <th>Amount</th>
                    <th>Company</th>
                    <th>ETA</th>
                    <th>Payment Type</th>
                    <th>Payment Status</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <a href="<?php echo e(route('bills.show', $bill)); ?>" class="d-flex align-items-center gap-2">
                            <i class="bi bi-receipt"></i>
                            <strong><?php echo e($bill->bill_code); ?></strong>
                        </a>
                    </td>
                    <td><?php echo e($bill->date?->format('M d, Y') ?? '—'); ?></td>
                    <td><?php echo e($bill->customer_received_date ? $bill->customer_received_date->format('M d, Y') : '—'); ?></td>
                    <td><?php echo e($bill->busDeparture ? \Carbon\Carbon::parse($bill->busDeparture->departure_time)->format('h:i A') : '—'); ?></td>
                    <td><strong>RM <?php echo e(number_format($bill->amount, 2)); ?></strong></td>
                    <td><?php echo e($bill->company?->name ?? '—'); ?></td>
                    <td><?php echo e($bill->eta ?? '—'); ?></td>
                    <td>
                        <?php
                            $payment = $bill->payment_details ? json_decode($bill->payment_details, true) : null;
                            $method = $payment['method'] ?? null;
                            $methodLabels = [
                                'cash' => 'Cash',
                                'bank_transfer' => 'Bank Transfer',
                                'e_wallet_qr' => 'E-wallet/QR',
                                'cod' => 'COD',
                                'credit_card' => 'Credit Card',
                                'e_wallet' => 'E-Wallet'
                            ];
                        ?>
                        <?php echo e($methodLabels[$method] ?? ($method ? ucfirst(str_replace('_', ' ', $method)) : '—')); ?>

                    </td>
                    <td><?php echo e($bill->is_paid ? 'Paid' : 'Unpaid'); ?></td>
                    <td class="text-end">
                        <div class="btn-group btn-group-sm">
                            <a href="<?php echo e(route('bills.show', $bill)); ?>" class="btn btn-outline-secondary" title="View">
                                <i class="bi bi-eye"></i>
                            </a>
                            <a href="<?php echo e(route('bills.template', $bill)); ?>" class="btn btn-outline-success" title="Download PDF">
                                <i class="bi bi-file-earmark-pdf"></i>
                            </a>
                            <a href="<?php echo e(route('bills.edit', $bill)); ?>" class="btn btn-outline-secondary" title="Edit">
                                <i class="bi bi-pencil"></i>
                            </a>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="d-flex justify-content-between align-items-center mt-3">
            <div class="text-muted" style="font-size:13px;">
                Showing <?php echo e($bills->firstItem() ?? 0); ?> to <?php echo e($bills->lastItem() ?? 0); ?> of <?php echo e($bills->total()); ?> bills
            </div>
            <div><?php echo e($bills->links()); ?></div>
        </div>
        <?php else: ?>
        <div class="tm-empty-state">
            <i class="bi bi-receipt"></i>
            <div class="title">No bills found</div>
            <p>Create your first bill to get started</p>
            <a href="<?php echo e(route('bills.create')); ?>" class="btn btn-primary mt-2">
                <i class="bi bi-plus-circle"></i> Create Bill
            </a>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\tungma\resources\views/bills/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="tm-header">
    <div>
        <h2 class="mb-1">Backup & Restore</h2>
        <div class="text-muted">Export and import bills data and media files</div>
    </div>
</div>


<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if(session('warning')): ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <?php echo e(session('warning')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>


<div class="row g-3">
    <div class="col-12">
        <div class="tm-card">
            <div class="tm-card-header">
                <i class="bi bi-hdd me-2"></i> Storage Metrics
            </div>
            <div class="tm-card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Storage Area</th>
                                <th>Size (MB)</th>
                                <th>Path</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><strong>Backups</strong></td>
                                <td><?php echo e(number_format($metrics['backups'] / 1048576, 2)); ?></td>
                                <td><small class="text-muted">storage/app/backups</small></td>
                                <td>
                                    <form method="POST" action="<?php echo e(route('backup.clear.storage')); ?>" class="d-inline"
                                          onsubmit="return confirm('Clear all backups? This cannot be undone!')">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="target" value="backups">
                                        <button type="submit" class="btn btn-sm btn-danger">
                                            <i class="bi bi-trash"></i> Clear
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Media Files</strong></td>
                                <td><?php echo e(number_format($metrics['media'] / 1048576, 2)); ?></td>
                                <td><small class="text-muted">storage/app/public</small></td>
                                <td>
                                    <form method="POST" action="<?php echo e(route('backup.clear.storage')); ?>" class="d-inline"
                                          onsubmit="return confirm('Clear all media files? This will delete bills attachments and other uploads!')">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="target" value="media">
                                        <button type="submit" class="btn btn-sm btn-danger">
                                            <i class="bi bi-trash"></i> Clear
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Logs</strong></td>
                                <td><?php echo e(number_format($metrics['logs'] / 1048576, 2)); ?></td>
                                <td><small class="text-muted">storage/logs</small></td>
                                <td>
                                    <form method="POST" action="<?php echo e(route('backup.clear.storage')); ?>" class="d-inline"
                                          onsubmit="return confirm('Clear all log files?')">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="target" value="logs">
                                        <button type="submit" class="btn btn-sm btn-danger">
                                            <i class="bi bi-trash"></i> Clear
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="row g-3 mt-2">
    <div class="col-md-6">
        <div class="tm-card">
            <div class="tm-card-header">
                <i class="bi bi-archive me-2"></i> Complete Backup
            </div>
            <div class="tm-card-body">
                <p class="text-muted mb-3">Backup data in one ZIP file</p>

                <form action="<?php echo e(route('backup.export.all')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-primary w-100 btn-lg">
                        <i class="bi bi-download"></i> Backup Everything
                    </button>
                    <small class="text-muted d-block mt-2">
                        Creates one ZIP with bills data
                    </small>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="tm-card">
            <div class="tm-card-header">
                <i class="bi bi-arrow-clockwise me-2"></i> Complete Restore
            </div>
            <div class="tm-card-body">
                <p class="text-muted mb-3">Restore everything from one ZIP file</p>

                <form action="<?php echo e(route('backup.import.all')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-2">
                        <input type="file" class="form-control <?php $__errorArgs = ['complete_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               id="complete_file" name="complete_file" accept=".zip" required>
                        <?php $__errorArgs = ['complete_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" name="backup_existing" id="backup_existing_all">
                        <label class="form-check-label" for="backup_existing_all">
                            Backup existing media before restore
                        </label>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 btn-lg">
                        <i class="bi bi-upload"></i> Restore Everything
                    </button>
                    <small class="text-muted d-block mt-2">
                        Restores bills data from backup ZIP
                    </small>
                </form>
            </div>
        </div>
    </div>
</div>


<div class="row g-3 mt-2">
    <div class="col-12">
        <details class="tm-card">
            <summary class="tm-card-header" style="cursor: pointer;">
                <i class="bi bi-sliders me-2"></i> Advanced: Individual Backup/Restore
            </summary>
            <div class="tm-card-body">
                <div class="row g-3">
                    
                    <div class="col-md-6">
                        <h6 class="mb-2">Export / Backup</h6>
                        
                        <form action="<?php echo e(route('backup.export.data')); ?>" method="POST" class="mb-2">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-outline-secondary btn-sm w-100">
                                <i class="bi bi-file-earmark-text"></i> Data Only (JSON)
                            </button>
                        </form>

                        
                        <form action="<?php echo e(route('backup.export.media')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-outline-secondary btn-sm w-100">
                                <i class="bi bi-file-earmark-zip"></i> Media Only (ZIP)
                            </button>
                        </form>
                    </div>

                    
                    <div class="col-md-6">
                        <h6 class="mb-2">Import / Restore</h6>
                        
                        <form action="<?php echo e(route('backup.import.data')); ?>" method="POST" enctype="multipart/form-data" class="mb-2">
                            <?php echo csrf_field(); ?>
                            <input type="file" class="form-control form-control-sm mb-1"
                                   id="data_file" name="data_file" accept=".json,.txt" required>
                            <button type="submit" class="btn btn-outline-secondary btn-sm w-100">
                                <i class="bi bi-upload"></i> Restore Data (JSON)
                            </button>
                        </form>

                        
                        <form action="<?php echo e(route('backup.import.media')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="file" class="form-control form-control-sm mb-1"
                                   id="media_file" name="media_file" accept=".zip" required>
                            <button type="submit" class="btn btn-outline-secondary btn-sm w-100">
                                <i class="bi bi-upload"></i> Restore Media (ZIP)
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </details>
    </div>
</div>


<div class="row g-3 mt-2">
    <div class="col-12">
        <div class="tm-card">
            <div class="tm-card-header">
                <i class="bi bi-folder2-open me-2"></i> Existing Backups
            </div>
            <div class="tm-card-body">
                <?php if(count($backups) > 0): ?>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Filename</th>
                                    <th>Type</th>
                                    <th>Size</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $backups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $backup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><small><?php echo e($backup['filename']); ?></small></td>
                                        <td>
                                            <span class="badge bg-secondary"><?php echo e($backup['type']); ?></span>
                                        </td>
                                        <td><?php echo e($backup['size_human']); ?></td>
                                        <td><?php echo e($backup['date']); ?></td>
                                        <td>
                                            <a href="<?php echo e(asset('storage/backups/' . $backup['filename'])); ?>"
                                               class="btn btn-sm btn-primary" download>
                                                <i class="bi bi-download"></i>
                                            </a>
                                            <form action="<?php echo e(route('backup.delete')); ?>" method="POST"
                                                  class="d-inline"
                                                  onsubmit="return confirm('Delete this backup?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <input type="hidden" name="filename" value="<?php echo e($backup['filename']); ?>">
                                                <button type="submit" class="btn btn-sm btn-danger">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted text-center py-4">No backups found. Create your first backup above.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\tungma\resources\views/backup/index.blade.php ENDPATH**/ ?>
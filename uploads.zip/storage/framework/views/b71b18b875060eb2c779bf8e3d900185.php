<?php $__env->startSection('content'); ?>
<div class="tm-header">
    <div>
        <h2 class="mb-1">Courier Policies</h2>
        <div class="text-muted">Define and manage delivery rules</div>
    </div>
    <a href="<?php echo e(route('policies.create')); ?>" class="btn btn-primary">New Policy</a>
</div>

<div class="tm-card tm-table">
    <div class="tm-card-body">
        <table class="table">
            <thead><tr><th>Name</th><th>Company</th><th class="text-end">Actions</th></tr></thead>
            <tbody>
            <?php $__currentLoopData = $policies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $policy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a href="<?php echo e(route('policies.show', $policy)); ?>"><?php echo e($policy->name); ?></a></td>
                    <td><?php echo e($policy->company?->name); ?></td>
                    <td class="text-end">
                        <div class="d-inline-flex gap-1">
                            <a href="<?php echo e(route('policies.show', $policy)); ?>" class="btn btn-sm btn-outline-primary">View</a>
                            <a href="<?php echo e(route('policies.edit', $policy)); ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
                            <form action="<?php echo e(route('policies.destroy', $policy)); ?>" method="POST" onsubmit="return confirm('Delete this policy?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="mt-2"><?php echo e($policies->links()); ?></div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\tungma\resources\views/policies/index.blade.php ENDPATH**/ ?>
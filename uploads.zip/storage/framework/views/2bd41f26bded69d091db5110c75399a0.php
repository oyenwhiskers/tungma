<?php $__env->startSection('content'); ?>
<h2>Edit Profile</h2>
<form method="post" action="<?php echo e(route('profile.update')); ?>" class="mt-3">
  <?php echo csrf_field(); ?>
  <?php echo method_field('PUT'); ?>
  <div class="mb-2"><label class="form-label">Full Name</label><input class="form-control" name="name" value="<?php echo e(auth()->user()->name); ?>" required></div>
  <div class="mb-2"><label class="form-label">Username</label><input class="form-control" name="username" value="<?php echo e(auth()->user()->username); ?>"></div>
  <div class="mb-2"><label class="form-label">Contact Number</label><input class="form-control" name="contact_number" value="<?php echo e(auth()->user()->contact_number); ?>"></div>
  <div class="mb-2"><label class="form-label">Date of Birth</label><input type="date" class="form-control" name="date_of_birth" value="<?php echo e(auth()->user()->date_of_birth); ?>"></div>
  <div class="mb-2"><label class="form-label">Gender</label><input class="form-control" name="gender" value="<?php echo e(auth()->user()->gender); ?>"></div>
  <div class="mb-2"><label class="form-label">IC Number</label><input class="form-control" name="ic_number" value="<?php echo e(auth()->user()->ic_number); ?>"></div>
  <div class="mb-2"><label class="form-label">Position</label><input class="form-control" name="position" value="<?php echo e(auth()->user()->position); ?>"></div>
  <div class="mb-2"><label class="form-label">Email</label><input type="email" class="form-control" name="email" value="<?php echo e(auth()->user()->email); ?>"></div>
  <button class="btn btn-primary">Save</button>
</form>

<hr class="my-4">

<h3>Change Password</h3>
<form method="post" action="<?php echo e(route('profile.changePassword')); ?>" class="mt-3">
  <?php echo csrf_field(); ?>
  <div class="mb-2"><label class="form-label">Current Password</label><input type="password" class="form-control" name="current_password" required></div>
  <div class="mb-2"><label class="form-label">New Password</label><input type="password" class="form-control" name="new_password" required></div>
  <div class="mb-2"><label class="form-label">Confirm New Password</label><input type="password" class="form-control" name="new_password_confirmation" required></div>
  <button class="btn btn-warning">Change Password</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\tungma\resources\views/profile/edit.blade.php ENDPATH**/ ?>
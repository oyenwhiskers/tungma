<?php $__env->startSection('content'); ?>
<div class="tm-breadcrumb">
    <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
    <i class="bi bi-chevron-right"></i>
    <span>Checklists</span>
</div>

<div class="tm-header">
    <div>
        <h2 class="mb-1">Daily Checklists</h2>
        <div class="text-muted">
            Manage bus departure checklists for <?php echo e(\Carbon\Carbon::parse($date)->format('d M Y')); ?>

        </div>
    </div>
    <div>
        <form method="GET" action="<?php echo e(route('checklists.index')); ?>" class="d-flex gap-2">
            <input type="date" name="date" class="form-control" value="<?php echo e($date); ?>" max="<?php echo e(now()->toDateString()); ?>">
            <button type="submit" class="btn btn-outline-secondary">
                <i class="bi bi-search"></i>
            </button>
        </form>
    </div>
</div>

    <div class="row">
        <div class="col-12">
            <div class="tm-card">
                <div class="tm-card-header">
                    <i class="bi bi-list-check me-2" style="color:var(--tm-primary);"></i>
                    Departures
                </div>
                <div class="tm-card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Departure Time</th>
                                    <th>Status</th>
                                    <th>Checked By</th>
                                    <th class="text-end">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($row['departure_time'] ? \Carbon\Carbon::parse($row['departure_time'])->format('H:i') : '—'); ?></td>
                                        <td>
                                            <?php if($row['status'] === 'success'): ?>
                                                <span class="badge bg-success">Completed</span>
                                            <?php elseif($row['status'] === 'pending'): ?>
                                                <span class="badge bg-warning text-dark">Pending</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">No Data</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($row['checked_by']); ?></td>
                                        <td class="text-end">
                                            <?php if($row['status'] !== 'no data' && $row['bus_departures_id']): ?>
                                                <a href="<?php echo e(route('checklists.show', ['bus_departures_id' => $row['bus_departures_id'], 'date' => $row['date']])); ?>"
                                                    class="btn btn-sm btn-primary">
                                                    View
                                                </a>
                                            <?php else: ?>
                                                <button class="btn btn-sm btn-secondary" disabled>View</button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="text-center py-4 text-muted">
                                            No departures found for today.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\tungma\resources\views/checklists/index.blade.php ENDPATH**/ ?>
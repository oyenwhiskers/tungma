<?php $__env->startSection('content'); ?>
    <div class="tm-header">
        <div>
            <h2>Bus Departures</h2>
            <div class="text-muted">Manage bus departure times.</div>
        </div>
        <div>
            <a href="<?php echo e(route('bus-departures.create')); ?>" class="btn btn-primary">
                <i class="bi bi-plus-lg"></i> Add New
            </a>
        </div>
    </div>

    <div class="tm-card tm-table">
        <div class="tm-card-header">All Departures</div>
        <div class="tm-card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Departure Time</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $busDepartures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e(\Carbon\Carbon::parse($departure->departure_time)->format('g:i A')); ?></td>
                                <td class="text-end">
                                    <div class="btn-group">
                                        <a href="<?php echo e(route('bus-departures.edit', $departure->id)); ?>"
                                            class="btn btn-sm btn-outline-secondary">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <form action="<?php echo e(route('bus-departures.destroy', $departure->id)); ?>" method="POST"
                                            class="d-inline" onsubmit="return confirm('Are you sure?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="2" class="text-center py-4 text-muted">
                                    No departures found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\tungma\resources\views/bus_departures/index.blade.php ENDPATH**/ ?>
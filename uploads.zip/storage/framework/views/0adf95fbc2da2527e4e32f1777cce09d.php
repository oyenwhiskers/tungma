<?php
use Illuminate\Support\Facades\Storage;
?>

<?php $__env->startSection('content'); ?>
<div class="tm-breadcrumb">
    <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
    <i class="bi bi-chevron-right"></i>
    <a href="<?php echo e(route('bills.index')); ?>">Bills</a>
    <i class="bi bi-chevron-right"></i>
    <a href="<?php echo e(route('bills.show', $bill)); ?>"><?php echo e($bill->bill_code); ?></a>
    <i class="bi bi-chevron-right"></i>
    <span>Edit</span>
</div>

<div class="tm-header">
  <div>
    <h2 class="mb-1">Edit Bill <?php echo e($bill->bill_code); ?></h2>
    <div class="text-muted">Update bill information</div>
  </div>
</div>

<?php
  $payment = is_string($bill->payment_details) ? json_decode($bill->payment_details, true) : $bill->payment_details;
  $customer = is_string($bill->customer_info) ? json_decode($bill->customer_info, true) : $bill->customer_info;
  $sst = is_string($bill->sst_details) ? json_decode($bill->sst_details, true) : $bill->sst_details;
?>

<div class="row g-3">
  <div class="col-md-8">
    <div class="tm-card">
      <div class="tm-card-header">
        <i class="bi bi-receipt me-2"></i> Bill Information
      </div>
      <div class="tm-card-body">
        <form method="post" action="<?php echo e(route('bills.update', $bill)); ?>" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>

          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">
                <i class="bi bi-hash"></i> Bill Code <span class="text-danger">*</span>
              </label>
              <input type="text" name="bill_code" class="form-control <?php $__errorArgs = ['bill_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('bill_code', $bill->bill_code)); ?>" required>
              <div class="form-text">Unique identifier for this bill</div>
              <?php $__errorArgs = ['bill_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6">
              <label class="form-label">
                <i class="bi bi-calendar"></i> Bill Date <span class="text-danger">*</span>
              </label>
              <input type="date" name="date" class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('date', $bill->date?->format('Y-m-d'))); ?>" required>
              <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6">
              <label class="form-label">
                <i class="bi bi-bus-front"></i> Bus Departure DateTime
              </label>
              <input type="datetime-local" name="bus_datetime" class="form-control <?php $__errorArgs = ['bus_datetime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('bus_datetime', $bill->bus_datetime ? $bill->bus_datetime->format('Y-m-d\TH:i') : '')); ?>">
              <div class="form-text">Vehicle departure datetime for grouping bills</div>
              <?php $__errorArgs = ['bus_datetime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6">
              <label class="form-label">
                <i class="bi bi-cash-stack"></i> Amount (RM) <span class="text-danger">*</span>
              </label>
              <input type="number" step="0.01" name="amount" class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('amount', $bill->amount)); ?>" required>
              <div class="form-text">Enter amount in Malaysian Ringgit</div>
              <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6">
              <label class="form-label">
                <i class="bi bi-truck"></i> ETA (Estimated Arrival)
              </label>
              <input type="text" name="eta" class="form-control <?php $__errorArgs = ['eta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('eta', $bill->eta)); ?>" placeholder="e.g., 3-5 business days">
              <?php $__errorArgs = ['eta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-12">
              <label class="form-label">
                <i class="bi bi-file-text"></i> Description
              </label>
              <textarea name="description" rows="3" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="Additional details about this bill"><?php echo e(old('description', $bill->description)); ?></textarea>
              <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>

          <hr class="my-4">
          <h5 class="mb-3"><i class="bi bi-credit-card me-2"></i>Payment Details</h5>

          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">
                <i class="bi bi-credit-card-2-front"></i> Payment Method
              </label>
              <select name="payment_method" class="form-select <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="">Select payment method</option>
                <option value="cash" <?php echo e(old('payment_method', $payment['method'] ?? '') == 'cash' ? 'selected' : ''); ?>>Cash</option>
                <option value="bank_transfer" <?php echo e(old('payment_method', $payment['method'] ?? '') == 'bank_transfer' ? 'selected' : ''); ?>>Bank Transfer</option>
                <option value="e_wallet_qr" <?php echo e(old('payment_method', $payment['method'] ?? '') == 'e_wallet_qr' ? 'selected' : ''); ?>>E-wallet/QR</option>
                <option value="cod" <?php echo e(old('payment_method', $payment['method'] ?? '') == 'cod' ? 'selected' : ''); ?>>COD</option>
              </select>
              <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6">
              <label class="form-label">
                <i class="bi bi-calendar-check"></i> Payment Date
              </label>
              <input type="date" name="payment_date" class="form-control <?php $__errorArgs = ['payment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('payment_date', $payment['date'] ?? '')); ?>">
              <?php $__errorArgs = ['payment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>

          <hr class="my-4">
          <h5 class="mb-3"><i class="bi bi-receipt me-2"></i>Payment Proof (QR, Bank Transfer)</h5>

          <div class="row g-3">
            <div class="col-12">
              <label class="form-label">
                <i class="bi bi-paperclip"></i> Upload Payment Proof
              </label>
              <input type="file" name="payment_proof_attachment" accept="image/jpeg,image/jpg,image/png,image/gif,image/webp,application/pdf" class="form-control <?php $__errorArgs = ['payment_proof_attachment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
              <div class="form-text">Upload receipt/transfer slip (JPG, PNG, GIF, WEBP, PDF; max 5MB)</div>
              <?php $__errorArgs = ['payment_proof_attachment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>

          <hr class="my-4">
          <h5 class="mb-3"><i class="bi bi-info-circle me-2"></i>Bill Status & Tracking</h5>

          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">
                <i class="bi bi-check-circle"></i> Payment Status
              </label>
              <select name="is_paid" class="form-select <?php $__errorArgs = ['is_paid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="0" <?php echo e(old('is_paid', $bill->is_paid ? '1' : '0') == '0' ? 'selected' : ''); ?>>Unpaid</option>
                <option value="1" <?php echo e(old('is_paid', $bill->is_paid ? '1' : '0') == '1' ? 'selected' : ''); ?>>Paid</option>
              </select>
              <?php $__errorArgs = ['is_paid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            

            <div class="col-md-6">
              <label class="form-label">
                <i class="bi bi-person-plus"></i> Created By
              </label>
              <input type="text" class="form-control" value="<?php echo e($bill->creator->name ?? 'N/A'); ?> (<?php echo e($bill->creator->role ?? 'N/A'); ?>)" disabled>
              <div class="form-text">Original creator of this bill</div>
            </div>
          </div>

          <hr class="my-4">
          <h5 class="mb-3"><i class="bi bi-arrow-left-right me-2"></i>Company-to-Company Routing</h5>

          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">
                <i class="bi bi-building"></i> From Company
              </label>
              <select name="from_company_id" class="form-select <?php $__errorArgs = ['from_company_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="">Select origin company</option>
                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($company->id); ?>" <?php echo e(old('from_company_id', $bill->from_company_id) == $company->id ? 'selected' : ''); ?>>
                    <?php echo e($company->name); ?>

                  </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <?php $__errorArgs = ['from_company_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6">
              <label class="form-label">
                <i class="bi bi-building-fill"></i> To Company
              </label>
              <select name="to_company_id" class="form-select <?php $__errorArgs = ['to_company_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="">Select destination company</option>
                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($company->id); ?>" <?php echo e(old('to_company_id', $bill->to_company_id) == $company->id ? 'selected' : ''); ?>>
                    <?php echo e($company->name); ?>

                  </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <?php $__errorArgs = ['to_company_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6">
              <label class="form-label">
                <i class="bi bi-person"></i> Sender Name
              </label>
              <input type="text" name="sender_name" class="form-control <?php $__errorArgs = ['sender_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('sender_name', $bill->sender_name)); ?>" placeholder="Person sending the package">
              <?php $__errorArgs = ['sender_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6">
              <label class="form-label">
                <i class="bi bi-telephone"></i> Sender Phone
              </label>
              <input type="text" name="sender_phone" class="form-control <?php $__errorArgs = ['sender_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('sender_phone', $bill->sender_phone)); ?>" placeholder="+60 12-345 6789">
              <?php $__errorArgs = ['sender_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6">
              <label class="form-label">
                <i class="bi bi-person-fill"></i> Receiver Name
              </label>
              <input type="text" name="receiver_name" class="form-control <?php $__errorArgs = ['receiver_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('receiver_name', $bill->receiver_name)); ?>" placeholder="Person receiving the package">
              <?php $__errorArgs = ['receiver_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6">
              <label class="form-label">
                <i class="bi bi-telephone-fill"></i> Receiver Phone
              </label>
              <input type="text" name="receiver_phone" class="form-control <?php $__errorArgs = ['receiver_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('receiver_phone', $bill->receiver_phone)); ?>" placeholder="+60 12-345 6789">
              <?php $__errorArgs = ['receiver_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>

          <hr class="my-4">
          <h5 class="mb-3"><i class="bi bi-person me-2"></i>Customer Information</h5>

          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">
                <i class="bi bi-person-badge"></i> Customer Name
              </label>
              <input type="text" name="customer_name" class="form-control <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('customer_name', $customer['name'] ?? '')); ?>">
              <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6">
              <label class="form-label">
                <i class="bi bi-telephone"></i> Customer Contact
              </label>
              <input type="text" name="customer_phone" class="form-control <?php $__errorArgs = ['customer_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('customer_phone', $customer['phone'] ?? '')); ?>" placeholder="+60 12-345 6789">
              <?php $__errorArgs = ['customer_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6">
              <label class="form-label">
                <i class="bi bi-person-vcard"></i> Customer IC Number
              </label>
              <input type="text" name="customer_ic_number" class="form-control <?php $__errorArgs = ['customer_ic_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('customer_ic_number', $bill->customer_ic_number ?? ($customer['ic'] ?? ''))); ?>" placeholder="e.g., 910101-01-1234">
              <?php $__errorArgs = ['customer_ic_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6">
              <label class="form-label">
                <i class="bi bi-calendar-check"></i> Customer Received Date
              </label>
              <input type="date" name="customer_received_date" class="form-control <?php $__errorArgs = ['customer_received_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('customer_received_date', $bill->customer_received_date?->format('Y-m-d'))); ?>">
              <?php $__errorArgs = ['customer_received_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-12">
              <label class="form-label">
                <i class="bi bi-geo-alt"></i> Customer Address
              </label>
              <textarea name="customer_address" rows="2" class="form-control <?php $__errorArgs = ['customer_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="Complete delivery address"><?php echo e(old('customer_address', $customer['address'] ?? '')); ?></textarea>
              <?php $__errorArgs = ['customer_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>

          <hr class="my-4">
          <h5 class="mb-3"><i class="bi bi-building me-2"></i>Company</h5>

          <div class="row g-3">
            <?php if(auth()->user()->role === 'admin'): ?>
              
              <input type="hidden" name="company_id" id="company_id" value="<?php echo e(auth()->user()->company_id); ?>">
              <div class="col-md-6">
                <label class="form-label">
                  <i class="bi bi-building"></i> Company
                </label>
                <input type="text" class="form-control" value="<?php echo e(auth()->user()->company->name ?? 'N/A'); ?>" disabled>
                <div class="form-text">Your assigned company</div>
              </div>
            <?php else: ?>
              
              <div class="col-md-6">
                <label class="form-label">
                  <i class="bi bi-building"></i> Company <span class="text-danger">*</span>
                </label>
                <select name="company_id" id="company_id" class="form-select <?php $__errorArgs = ['company_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                  <option value="">Select company</option>
                  <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($company->id); ?>" <?php echo e(old('company_id', $bill->company_id) == $company->id ? 'selected' : ''); ?>>
                      <?php echo e($company->name); ?>

                    </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['company_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            <?php endif; ?>

            <div class="col-md-6">
              <label class="form-label">
                <i class="bi bi-shield-check"></i> Courier Policy
              </label>
              <select name="courier_policy_id" id="courier_policy_id" class="form-select <?php $__errorArgs = ['courier_policy_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="">Select courier policy</option>
                <?php $__currentLoopData = $policies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $policy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($policy->id); ?>"
                          data-company-id="<?php echo e($policy->company_id); ?>"
                          <?php echo e(old('courier_policy_id', $bill->courier_policy_id) == $policy->id ? 'selected' : ''); ?>>
                    <?php echo e($policy->name); ?>

                  </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <div class="form-text">Select a courier policy for this company</div>
              <?php $__errorArgs = ['courier_policy_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>

          <hr class="my-4">
          <h5 class="mb-3"><i class="bi bi-receipt-cutoff me-2"></i>SST (Sales & Service Tax)</h5>

          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">
                <i class="bi bi-percent"></i> SST Rate (%)
              </label>
              <input type="number" step="0.01" name="sst_rate" class="form-control <?php $__errorArgs = ['sst_rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('sst_rate', $sst['rate'] ?? '0')); ?>" placeholder="e.g., 6">
              <div class="form-text">Enter SST percentage rate</div>
              <?php $__errorArgs = ['sst_rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6">
              <label class="form-label">
                <i class="bi bi-currency-dollar"></i> SST Amount (RM)
              </label>
              <input type="number" step="0.01" name="sst_amount" class="form-control <?php $__errorArgs = ['sst_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('sst_amount', $sst['amount'] ?? '0')); ?>" placeholder="0.00">
              <div class="form-text">Calculated SST amount</div>
              <?php $__errorArgs = ['sst_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>

          <hr class="my-4">
          <h5 class="mb-3"><i class="bi bi-paperclip me-2"></i>Media Attachment</h5>

          <div class="row g-3">
            <div class="col-12">
              <label class="form-label">
                <i class="bi bi-image"></i> Upload Image
              </label>
              <input type="file" name="media_attachment" accept="image/jpeg,image/jpg,image/png,image/gif,image/webp" class="form-control <?php $__errorArgs = ['media_attachment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
              <div class="form-text">Upload a single image file (max 5MB). Accepted formats: JPG, PNG, GIF, WEBP</div>
              <?php if($bill->media_attachment): ?>
                <div class="mt-2">
                  <small class="text-muted">Current attachment: </small>
                  <a href="<?php echo e(Storage::url($bill->media_attachment)); ?>" target="_blank" class="text-primary">
                    <i class="bi bi-image"></i> View Current Image
                  </a>
                </div>
              <?php endif; ?>
              <?php $__errorArgs = ['media_attachment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>

          <div class="mt-4 d-flex gap-2">
            <button type="submit" class="btn btn-primary">
              <i class="bi bi-check-lg"></i> Update Bill
            </button>
            <a href="<?php echo e(route('bills.show', $bill)); ?>" class="btn btn-outline-secondary">
              <i class="bi bi-x-lg"></i> Cancel
            </a>
          </div>
        </form>
      </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="tm-card">
      <div class="tm-card-header">
        <i class="bi bi-clock-history me-2"></i> History
      </div>
      <div class="tm-card-body">
        <div class="mb-3">
          <div class="text-muted small mb-1">Created</div>
          <div class="small"><?php echo e($bill->created_at->format('M d, Y h:i A')); ?></div>
        </div>
        <div>
          <div class="text-muted small mb-1">Last Updated</div>
          <div class="small"><?php echo e($bill->updated_at->format('M d, Y h:i A')); ?></div>
        </div>
      </div>
    </div>

    <div class="tm-card mt-3">
      <div class="tm-card-header">
        <i class="bi bi-lightbulb me-2"></i> Tips
      </div>
      <div class="tm-card-body">
        <ul class="small mb-0 ps-3">
          <li class="mb-2">Bill code must remain unique</li>
          <li class="mb-2">Payment details help track transaction status</li>
          <li class="mb-2">Update customer info if delivery details change</li>
          <li>Attach updated documents as needed</li>
        </ul>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
  (function(){
    const companySelect = document.getElementById('company_id');
    const policySelect = document.getElementById('courier_policy_id');

    if (!companySelect || !policySelect) return;

    function filterPolicies() {
      // Get company ID - works for both select and hidden input
      const companyId = companySelect.value || companySelect.getAttribute('value');
      if (!companyId) return;

      [...policySelect.options].forEach((opt) => {
        if (!opt.value) return; // skip placeholder
        const cid = opt.getAttribute('data-company-id');
        opt.hidden = companyId && cid !== companyId;
      });
      // If selected option hidden, reset
      const selected = policySelect.selectedOptions[0];
      if (selected && selected.hidden) {
        policySelect.value = '';
      }
    }

    // Only add change listener if it's a select element (super admin)
    if (companySelect.tagName === 'SELECT') {
      companySelect.addEventListener('change', filterPolicies);
    }

    // Initial filter (works for both admin and super admin)
    filterPolicies();
  })();
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\tungma\resources\views/bills/edit.blade.php ENDPATH**/ ?>